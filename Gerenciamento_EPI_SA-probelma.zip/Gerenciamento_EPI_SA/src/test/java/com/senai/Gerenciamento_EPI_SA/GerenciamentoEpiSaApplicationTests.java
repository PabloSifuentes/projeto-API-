package com.senai.Gerenciamento_EPI_SA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciamentoEpiSaApplicationTests {

	@Test
	void contextLoads() {
	}

}
