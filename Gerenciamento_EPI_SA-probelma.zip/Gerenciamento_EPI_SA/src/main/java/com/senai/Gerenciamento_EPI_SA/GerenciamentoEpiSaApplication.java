package com.senai.Gerenciamento_EPI_SA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciamentoEpiSaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerenciamentoEpiSaApplication.class, args);
	}

}
